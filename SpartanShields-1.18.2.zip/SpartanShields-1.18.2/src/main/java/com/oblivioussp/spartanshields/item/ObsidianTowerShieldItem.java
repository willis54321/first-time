package com.oblivioussp.spartanshields.item;

/*import java.util.function.Consumer;

import com.oblivioussp.spartanshields.client.render.item.TowerShieldBEWLR;
import com.oblivioussp.spartanshields.util.TierSS;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraftforge.client.IItemRenderProperties;

public class ObsidianTowerShieldItem extends ObsidianShieldItem
{

	public ObsidianTowerShieldItem(String unlocName, TierSS toolMaterial, int defaultMaxDamage, Properties prop) {
		super(unlocName, toolMaterial, defaultMaxDamage, prop);
	}

	@Override
	public void initializeClient(Consumer<IItemRenderProperties> consumer) 
	{
		consumer.accept(new IItemRenderProperties() {
			@Override
			public BlockEntityWithoutLevelRenderer getItemStackRenderer() 
			{
				return TowerShieldBEWLR.INSTANCE;
			}
		});
	}
}*/
