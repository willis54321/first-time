# SpartanShields
Adds a variety of new shields to Minecraft.<br>
Now open source under the Apache License 2.0!<br>
Find the page for the mod on CurseForge here: https://www.curseforge.com/minecraft/mc-mods/spartan-shields